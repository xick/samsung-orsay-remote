echo " /mtd_rwarea/network/insmod_bcm.sh begin"
echo 1 > /dtv/NET_OK
/bin/sh /mtd_rwarea/network/runSamyGO.sh &
insmod /lib/modules/cfg80211.ko
insmod /mtd_cmmlib/WIFI_LIB/BRCM/bcm_dbus.ko
insmod /mtd_cmmlib/WIFI_LIB/BRCM/wl.ko init_ccode="XR/57"
echo " /mtd_rwarea/network/insmod_bcm.sh end"
