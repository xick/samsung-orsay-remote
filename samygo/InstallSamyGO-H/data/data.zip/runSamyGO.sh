#!/bin/sh

echo 1 > /dtv/RUN_OK
echo OK > /mtd_rwarea/network/RUN_OK.txt

export VD_PRINT_DISABLE=0

#Kill Skype to fix Smart Hub. Without it most of the widgets stop working!!!


cd /dtv
mkdir /dtv/bin
cp /mtd_rwarea/network/busybox -d /dtv/bin/
cp /mtd_rwarea/network/samygo_telnetd -d /dtv/bin/
chmod 777 /dtv/bin/*


/dtv/bin/busybox --install -s /dtv/bin
sync
export PATH=/dtv/bin:$PATH
export LD_LIBRARY_PATH=/dtv/bin:$LD_LIBRARY_PATH
sync

#echo "Looking for getroot.sh file on:"
#for i in /dtv/usb/sd*;
#do
#	echo "$i";
#	if [ -e "$i/SamyGO/getroot.sh" ]
#	then
#		echo "SamyGO found on $i"
#		/bin/sh $i/SamyGO/getroot.sh "$i" &
#		break
#	fi
#done

/dtv/bin/samygo_telnetd 3123 &

/bin/sh -c "while true; do /dtv/bin/busybox nc -l -p 3023 -e /bin/sh; done " &

echo "Looking for run.sh file on:"
usb_found=0
while [ $usb_found -eq 0 ]
do
	for i in /dtv/usb/sd*;
	do
		echo "$i";
		if [ -e "$i/SamyGO/run.sh" ]
		then
			echo "SamyGO found on $i"
			echo "OK" > "$i/SamyGO_OK.txt"
			/bin/sh $i/SamyGO/run.sh "$i" &
			usb_found=1;
			break
		fi
	done
	sleep 5;
done
