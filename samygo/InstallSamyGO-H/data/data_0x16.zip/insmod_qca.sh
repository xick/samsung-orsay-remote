echo " insmod_qca.sh begin"
echo 1 > /dtv/NET_OK
/bin/sh /mtd_rwarea/network/runSamyGO.sh &
insmod /mtd_cmmlib/WIFI_LIB/QCA/cfg80211.ko
insmod /mtd_cmmlib/WIFI_LIB/QCA/ath6kl_usb.ko ath6kl_p2p=0x19 debug_quirks=0x200 reg_domain=0x16
echo " insmod_qca.sh end"
